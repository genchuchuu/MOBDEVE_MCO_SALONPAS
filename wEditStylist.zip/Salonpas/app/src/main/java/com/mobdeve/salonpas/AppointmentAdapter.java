package com.mobdeve.salonpas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AppointmentAdapter extends RecyclerView.Adapter<AppointmentAdapter.AppointmentViewHolder> {

    private List<Appointment> appointmentList;

    public AppointmentAdapter(List<Appointment> appointmentList) {
        this.appointmentList = appointmentList;
    }

    @NonNull
    @Override
    public AppointmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.appointment_item, parent, false);
        return new AppointmentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AppointmentViewHolder holder, int position) {
        Appointment appointment = appointmentList.get(position);

        holder.appointmentDate.setText(appointment.getDate() + " at " + appointment.getTime());
        holder.serviceDescription.setText(appointment.getServiceName());
        holder.stylistName.setText(appointment.getStylistName());

        // Handle Edit Button
        holder.editButton.setOnClickListener(v -> {
            // Implement the edit logic, such as opening an edit screen
        });

        // Handle Cancel Button
        holder.cancelButton.setOnClickListener(v -> {
            // Implement cancellation logic, such as removing the appointment from the database
        });
    }

    @Override
    public int getItemCount() {
        return appointmentList.size();
    }

    static class AppointmentViewHolder extends RecyclerView.ViewHolder {
        TextView appointmentDate;
        TextView serviceDescription;
        TextView stylistName;
        Button editButton;
        Button cancelButton;

        public AppointmentViewHolder(@NonNull View itemView) {
            super(itemView);
            appointmentDate = itemView.findViewById(R.id.appointmentDate);
            serviceDescription = itemView.findViewById(R.id.serviceDescription);
            stylistName = itemView.findViewById(R.id.stylistName);
            editButton = itemView.findViewById(R.id.editButton);
            cancelButton = itemView.findViewById(R.id.cancelButton);
        }
    }
}