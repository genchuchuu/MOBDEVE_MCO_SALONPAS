package com.mobdeve.salonpas;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ManageAppointment extends AppCompatActivity {

    private List<Appointment> appointments;
    private RecyclerView recyclerView;
    private AppointmentAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_appointment);

        recyclerView = findViewById(R.id.appointmentRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        appointments = new ArrayList<>();
        adapter = new AppointmentAdapter(appointments);
        recyclerView.setAdapter(adapter);

        fetchAppointmentsFromFirebase();
    }

    private void fetchAppointmentsFromFirebase() {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();

        databaseReference.child("Reservations").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot reservationSnapshot) {
                final Map<String, String> serviceNames = new HashMap<>();
                final Map<String, String> stylistNames = new HashMap<>();

                // Fetch Services and Stylists concurrently
                databaseReference.child("Services").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot serviceSnapshot) {
                        for (DataSnapshot service : serviceSnapshot.getChildren()) {
                            serviceNames.put(service.getKey(), service.child("name").getValue(String.class));
                        }

                        databaseReference.child("Stylists").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot stylistSnapshot) {
                                for (DataSnapshot stylist : stylistSnapshot.getChildren()) {
                                    stylistNames.put(stylist.getKey(), stylist.child("name").getValue(String.class));
                                }

                                // Process Reservations
                                for (DataSnapshot reservation : reservationSnapshot.getChildren()) {
                                    String date = reservation.child("date").getValue(String.class);
                                    String time = reservation.child("time").getValue(String.class);
                                    String serviceId = reservation.child("serviceId").getValue(String.class);
                                    String stylistId = reservation.child("stylistId").getValue(String.class);
                                    String userId = reservation.child("userId").getValue(String.class);

                                    String serviceName = serviceNames.get(serviceId);
                                    String stylistName = stylistNames.get(stylistId);

                                    appointments.add(new Appointment(date + " " + time, serviceName, stylistName, userId));
                                }

                                adapter.notifyDataSetChanged();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                // Handle error
                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        // Handle error
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle error
            }
        });
    }

    public void openAdminMainPage(View view) {
        Intent intent = new Intent(ManageAppointment.this, AdminMainPageActivity.class);
        startActivity(intent);
    }

    public void manageService(View view) {
        Intent intent = new Intent(ManageAppointment.this, ManageServiceList.class);
        startActivity(intent);
    }

    public void manageStylist(View view) {
        Intent intent = new Intent(ManageAppointment.this, ManageStylist.class);
        startActivity(intent);
    }

    public void manageAppointment(View view) {
        Intent intent = new Intent(ManageAppointment.this, ManageAppointment.class);
        startActivity(intent);
    }

    public void openAdminNotification(View view) {
        Intent intent = new Intent(ManageAppointment.this, AdminNotificationActivity.class);
        startActivity(intent);
    }

    public void openAdminProfile(View view) {
        Intent intent = new Intent(ManageAppointment.this, AdminProfile.class);
        startActivity(intent);
    }
}